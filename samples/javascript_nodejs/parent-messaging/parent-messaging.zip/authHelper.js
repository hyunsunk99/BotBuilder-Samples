// move to package.json later
const { TeamsInfo } = require('botbuilder');
const { AdaptiveCardHelper } = require('./adaptiveCardHelper.js');
const { CardResponseHelpers } = require('./cardResponseHelpers.js');
const { EmailHelper } = require('./emailHelper.js');
const { SimpleGraphClient } = require('./simpleGraphClient.js');

class AuthHelper {
    static async handleEmailAuthCommand(context, action, connectionName) {
        const magicCode = (action.state && Number.isInteger(Number(action.state))) ? action.state : '';
        const tokenResponse = await context.adapter.getUserToken(context, connectionName, magicCode);

        if (!tokenResponse || !tokenResponse.token) {
            // There is no token, so the user has not signed in yet.
            // Retrieve the OAuth Sign in Link to use in the MessagingExtensionResult Suggested Actions
            const signInLink = await context.adapter.getSignInLink(context, connectionName);

            return {
                composeExtension: {
                    type: 'auth',
                    suggestedActions: {
                        actions: [{
                            type: 'openUrl',
                            value: signInLink,
                            title: 'Bot Service OAuth'
                        }]
                    }
                }
            };
        }

        // SIMPLE EMAIL WORKING  
        // await EmailHelper.sendMail(context, tokenResponse, 'hyunsunk@heidik87.onmicrosoft.com');

        // Retrieve user email after authentication
        const senderEmail = await EmailHelper.listEmailAddress(context, tokenResponse);
        console.log(senderEmail);

        const client = new SimpleGraphClient(tokenResponse.token);	

        // Retrieve team name 
        var teamName = '';
        var teamDetails;
        try {
            teamDetails = await TeamsInfo.getTeamDetails(context);
        } catch (e) {
            console.log(e);
            throw e;
        }
        if (teamDetails) {
            teamName = `${ teamDetails.name}`;
        }

        // Return either a sign-in modal (user not verified) or the email template (verified)

        // Retrieve recipient group ID (hard code for now)
        const recipientGroupID = teamName+' Parents & Guardians';
        console.log(recipientGroupID);

        const adaptiveCard = AdaptiveCardHelper.createAdaptiveCardEditor(senderEmail, recipientGroupID);
        return CardResponseHelpers.toTaskModuleResponse(adaptiveCard);
    }

    static async handleSignOutCommand(context, connectionName) {
        await context.adapter.signOutUser(context, connectionName);
        const adaptiveCard = AdaptiveCardHelper.createSignOutCard();
        return CardResponseHelpers.toSignOutResponse(adaptiveCard);
    }
}
exports.AuthHelper = AuthHelper;