// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { SimpleGraphClient } = require('./simpleGraphClient.js');

/**
 * These methods call the Microsoft Graph API. The following OAuth scopes are used:
 * 'OpenId' 'email' 'Mail.Send.Shared' 'Mail.Read' 'profile' 'User.Read' 'User.ReadBasic.All'
 * for more information about scopes see:
 * https://developer.microsoft.com/en-us/graph/docs/concepts/permissions_reference
 */
class EmailHelper {
    /**
     * Enable the user to send an email via the bot.
     * @param {TurnContext} context A TurnContext instance containing all the data needed for processing this conversation turn.	
     * @param {TokenResponse} tokenResponse A response that includes a user token.	
     * @param {string} emailAddress The email address of the recipient.	
     */	
    static async sendMail(context, tokenResponse, emailAddress) {	
        if (!context) {	
            throw new Error('OAuthHelpers.sendMail(): `context` cannot be undefined.');	
        }	
        if (!tokenResponse) {	
            throw new Error('OAuthHelpers.sendMail(): `tokenResponse` cannot be undefined.');	
        }	

        const client = new SimpleGraphClient(tokenResponse.token);	
        const me = await client.getMe();	

        await client.sendMail(	
            emailAddress,	
            'Message from a bot!',	
            `Hi there! I had this message sent from a bot. - Your friend, ${ me.displayName }`	
        );	
        await context.sendActivity(`I sent a message to ${ emailAddress } from your account.`);	
    }	

    /**	
     * Send the user their Graph Display Name from the bot.
     * @param {TurnContext} context A TurnContext instance containing all the data needed for processing this conversation turn.
     * @param {TokenResponse} tokenResponse A response that includes a user token.
     */
    static async listMe(context, tokenResponse) {
        if (!context) {
            throw new Error('OAuthHelpers.listMe(): `context` cannot be undefined.');
        }
        if (!tokenResponse) {
            throw new Error('OAuthHelpers.listMe(): `tokenResponse` cannot be undefined.');
        }

        // Pull in the data from Microsoft Graph.
        const client = new SimpleGraphClient(tokenResponse.token);
        const me = await client.getMe();

        return `${me.displayName}`;
        // await context.sendActivity(`You are ${ me.displayName }.`);
    }

    /**
     * Send the user their Graph Email Address from the bot.
     * @param {TurnContext} context A TurnContext instance containing all the data needed for processing this conversation turn.
     * @param {TokenResponse} tokenResponse A response that includes a user token.
     */
    static async listEmailAddress(context, tokenResponse) {
        if (!context) {
            throw new Error('OAuthHelpers.listEmailAddress(): `context` cannot be undefined.');
        }
        if (!tokenResponse) {
            throw new Error('OAuthHelpers.listEmailAddress(): `tokenResponse` cannot be undefined.');
        }

        // Pull in the data from Microsoft Graph.
        const client = new SimpleGraphClient(tokenResponse.token);
        const me = await client.getMe();

        return `${me.mail}`;
        // await context.sendActivity(`Your email: ${ me.mail }.`);
    }
}

exports.EmailHelper = EmailHelper;
